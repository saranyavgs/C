/*
Name : Saranya V
Date : 09-09-2022
Description : WAP to find 2nd largest element in an array
Sample Input and output:
Enter the size of the Array : 4
Enter the elements into the array: 66 22 11 3
Second largest element of the array is 22
*/

#include <stdio.h>                                  //Header file                     
int sec_largest(int *arr, int size)                 //function execution
{
	int i, largest=arr[0], smallest=arr[0], second_largest; //Define variable and array
	for (i=1; i<size; i++)                                   //Use loop to get one by one array element
	{
		if(*(arr+i) > largest)                               //arr[i]->interpreted by compiler as *(arr + i). Check and comapre the 1st element with all another element to find the largest element
		{
			largest=*(arr+i);                                //Largest element stored in largest variable                           
		}
		if(*(arr+i) < smallest)                              //Check and compare the 1st element with all another element to find the smallest element
		{
			smallest=*(arr+i);                               //Smallest element stored in smallest variable
		}
	}
		second_largest=smallest;                             //swap
		for(i=0; i<size; i++)                                //use loop to get one by one array element
		{
			if (*(arr+i) > second_largest && *(arr+i) < largest)   //check condition of i is greater than smallest element and less than largest element
			{
				second_largest=*(arr+i);                           //If condition true, then find second_largest element
			}
		}
  return second_largest;                                         //Return second_largest element
}

int main()                                           //main function
{
    int size, ret;                                   //function declaration
    printf("Enter the size of the array : ");         //prompt the size of the array
    scanf("%d", &size);                              //Read size from the user
	int arr[size];                                   //function declaration
	printf("Enter the elements into the array: ");    //prompt the elements of the array
    for(int i=0;i<size;i++)                          //Use loop to get one by one idex
    {
        scanf("%d",&arr[i]);                         //Read elements into the array
    }
    ret = sec_largest(arr, size);                    //function call
    
    printf("Second largest element of the array is %d\n", ret);  //Print second largest element
	return 0;                                                    //terminate the function
}
